





def action_percentge(a):
    return float(int(a)/100)