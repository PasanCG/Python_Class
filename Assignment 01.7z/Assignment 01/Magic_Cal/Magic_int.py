





def action_add(a,b):
    c= int(a)+ int(b)
    return f"addition of two variables are {c}"

def action_subtract(a,b):
    c= int(a)- int(b)
    return f"subtraction of two variables are {c}"

def action_division(a,b):
    c= int(a)/ int(b)
    return f"division of two variables are {c}"