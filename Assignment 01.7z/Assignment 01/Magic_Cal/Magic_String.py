





def action_double(a):
    return f"{a}{a}"
