import Magic_Cal.Magic_String as magic_string
import Magic_Cal.Magic_int as magic_int
import Magic_Cal.Magic_flote as magic_flote


def Magic_Cal_final(cal_input1,operation,cal_input2):

        if operation == 'A':
            return magic_string.action_double(cal_input1)
        elif operation == 'B':
            return magic_int.action_add(cal_input1,cal_input2)
        elif operation == 'C':
            return magic_int.action_subtract(cal_input1,cal_input2)
        elif operation == 'D':
            return magic_int.action_division(cal_input1,cal_input2)
        elif operation == 'E':
            return magic_flote.action_percentge(cal_input1)
        else:
            return "Invalid Operation"

if __name__ == '__main__':

    endcode = 'N'
    while endcode == 'N':

        in_1 = input("input your first variable")
        in_2 = input("input your operation (A/B/C/D/E)")
        if in_2 =='A':
            output_f1 = Magic_Cal_final(in_1,in_2,0)
        elif in_2 == 'E':
            output_f1 = Magic_Cal_final(in_1, in_2, 0)
        else:
            in_3 = input("input your Second variable")
            output_f1 = Magic_Cal_final(in_1, in_2,in_3)
        print(output_f1)
        endcode = input("Do you want to exit (Y/N)")
